-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 10 Oca 2021, 23:47:09
-- Sunucu sürümü: 10.4.10-MariaDB
-- PHP Sürümü: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `sifre_saklama`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanici_bilgileri`
--

DROP TABLE IF EXISTS `kullanici_bilgileri`;
CREATE TABLE IF NOT EXISTS `kullanici_bilgileri` (
  `kullanici_adi` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `kullanici_sifre` varchar(1305) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kullanici_bilgileri`
--

INSERT INTO `kullanici_bilgileri` (`kullanici_adi`, `kullanici_sifre`) VALUES
('fatih', 'gAAAAABf-5CwAKiverrhzSfMiPfKTn6rHCuX0zlJT-0lw5pWao1LtyikU4Ntpwz8zKNxBY5BARuj5d2K36mhc1RKUDB29K34tg==');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `site_bilgileri`
--

DROP TABLE IF EXISTS `site_bilgileri`;
CREATE TABLE IF NOT EXISTS `site_bilgileri` (
  `site_adi` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `site_adresi` varchar(200) COLLATE utf8_turkish_ci NOT NULL,
  `site_sifresi` varchar(500) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `site_bilgileri`
--

INSERT INTO `site_bilgileri` (`site_adi`, `site_adresi`, `site_sifresi`) VALUES
('youtube', 'www.youtube.com', 'gAAAAABf-5FVkd1_gHx0hWnA7n2piKm0Y_EjTbi4VVli0OOcqDHgIJ8liYzWP46rXCHu2_jrL3jpXED9yX_eUDxIF9hvzUu0qw=='),
('instagram', 'www.instagram.com', 'gAAAAABf-5F3fjuSh1AEtZrBkHEh7AGK3-_0LoERYxL3C-jf6FMDdJdUzrpw-x3seq2g7yIYta6QiF3jCSfH-eQFyp3OGYk9UA=='),
('facebook', 'www.facebook.com', 'gAAAAABf-5DuSyHvzwMNI8WyXaG9tne217YS5gMhxKkXbzg0VdFUrMN5n3684yKCt5lZlbzUw8DM5RESYS9tOZtfj5idN9QwYQ=='),
('twitter', 'www.twitter.com', 'gAAAAABf-5EGgcsbOqWLeRpRz5_N5-Lz9nf9fmOHVU65tMoQB40QkZEe8uwH1YQDXrr4irC9p1QZqK1fbHxNKBnnfufo4z8wJQ=='),
('github', 'www.github.com', 'gAAAAABf-5EzqJIgmGCdtfNslgKKn7SPnOW8Dp6gBXe21q3mxOW6BUYqljAUAmQIvdyt7brSDsJ98TfNamEcFuvNw_a3XO6ahA==');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
